// //! final Provider Data
// // Provider for a simple string
// class finalProvider {
//   final String message = "Hello from final Provider Data!";
// }

// // Provide it correctly
// Provider<finalProvider> finalProviderData = Provider(
//   create: (_) => finalProvider(),
// );
// //

// class CommonProviderScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     // Access the provider
//     final message = Provider.of<finalProvider>(context).message;

//     return Scaffold(
//       appBar: AppBar(title: Text("Using Provider<StringProvider>")),
//       body: Center(
//         child: Text(
//           message, // Display the provided string
//           style: TextStyle(fontSize: 24),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class demo {
  String name = "Abhi";
}

class AppConstants {
  final String tittle = "Abhi";
  final String message = "message";
  // Padding values
  final EdgeInsets defaultPadding = EdgeInsets.all(16.0);
  final EdgeInsets smallPadding = EdgeInsets.all(8.0);
  final EdgeInsets mediumPadding = EdgeInsets.all(24.0);
  final EdgeInsets largePadding = EdgeInsets.all(32.0);

  // Margin values
  final EdgeInsets defaultMargin = EdgeInsets.all(16.0);
  final EdgeInsets smallMargin = EdgeInsets.all(8.0);
  final EdgeInsets mediumMargin = EdgeInsets.all(24.0);
  final EdgeInsets largeMargin = EdgeInsets.all(32.0);

  // Border radius values
  final double defaultBorderRadius = 8.0;
  final double smallBorderRadius = 4.0;
  final double mediumBorderRadius = 12.0;
  final double largeBorderRadius = 16.0;

  // Size ants for SizedBox
  final double smallBoxSize = 12.0; // Height and Width for small SizedBox
  final double mediumBoxSize = 16.0; // Example for medium SizedBox
  final double largeBoxSize = 24.0; // Example for large SizedBox
}

Provider<AppConstants> appConstants = Provider(create: (_) => AppConstants());

////
class CommonProviderScreen extends StatelessWidget {
  demo demoC = demo();
  @override
  Widget build(BuildContext context) {
    // Access the provider
    final appConstants = Provider.of<AppConstants>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Using Provider<StringProvider>")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              appConstants.tittle.toString(), // Display the provided string
              style: TextStyle(fontSize: appConstants.defaultBorderRadius),
            ),
            Text(
              appConstants.defaultBorderRadius
                  .toString(), // Display the provided string
              style: TextStyle(fontSize: 24),
            ),
            Text(
              appConstants.message, // Display the provided string
              style: TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}
