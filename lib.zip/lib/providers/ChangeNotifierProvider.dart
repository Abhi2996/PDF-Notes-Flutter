// 📌 ChangeNotifierProvider (State Management)
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CounterProvider extends ChangeNotifier {
  int _count = 0;
  int get count => _count;

  void increment() {
    _count++;
    notifyListeners();
  }

  void dec() {
    _count--;
    notifyListeners();
  }

  Future<Widget> fetchTeamName() async {
    await Future.delayed(Duration(seconds: 2));
    return Text(
      "Flutter Developers Team",
      style: TextStyle(color: Colors.deepOrangeAccent, fontSize: 50),
    );
  }
}

// 📌 Counter Screen (ChangeNotifierProvider)
class CounterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final counter = context.watch<CounterProvider>();

    return Scaffold(
      appBar: AppBar(title: Text("Counter Example")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FutureBuilder(
              future: counter.fetchTeamName(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return snapshot.data!;
                } else {
                  return Text("data");
                }
              },
            ),

            Text("Counter: ${counter.count}", style: TextStyle(fontSize: 24)),
            SizedBox(height: 10),
            ElevatedButton(
              // onPressed: counter.increment,
              onPressed: () {
                counter.increment();
              },
              child: Text("Increment"),
            ),
            SizedBox(height: 12),
            ElevatedButton(onPressed: counter.dec, child: Text("Decrement")),
          ],
        ),
      ),
    );
  }
}
