// 📌 Simulated API Call (FutureProvider)
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

Future<Widget> fetchTeamName() async {
  await Future.delayed(Duration(seconds: 2));
  return Text(
    "Flutter Developers Team",
    style: TextStyle(color: Colors.deepOrangeAccent, fontSize: 50),
  );
}

// 📌 FutureProvider Screen (API Call)
class FutureProviderScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final teamName = context.watch<Widget>();

    return Scaffold(
      appBar: AppBar(title: Text("FutureProvider Example")),
      // body: Center(child: Text(teamName, style: TextStyle(fontSize: 24))),
      body: Center(child: teamName),
    );
  }
}

//! flutter framework FutureBuilder
/*
class FutureProviderScreen extends StatefulWidget {
  const FutureProviderScreen({super.key});

  @override
  State<FutureProviderScreen> createState() => _FutureProviderScreenState();
}

class _FutureProviderScreenState extends State<FutureProviderScreen> {
  Future<double> fetchTeamName() async {
    await Future.delayed(Duration(seconds: 5));
    // return "Flutter Developers TeamMM";
    return 0.5;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: fetchTeamName(),
        builder: (context, snapshot) {
          if (snapshot.data == null) {
            // return Center(child: Text("isEmpty"));
            return Center(
              child: SizedBox(
                width: 200,
                height: 200,
                child: CircularProgressIndicator(),
              ),
            );
          } else if (snapshot.hasError) {
            return Text("${snapshot.hasError}");
          } else if (snapshot.hasData) {
            return Center(
              child: Text(
                snapshot.data!.toString(),
                style: TextStyle(fontSize: 24),
              ),
            );
          } else {
            return Text("data");
          }
        },
      ),
    );
  }
}
*/
