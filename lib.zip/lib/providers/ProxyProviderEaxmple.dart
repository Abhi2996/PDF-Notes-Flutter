// 📌 AuthProvider (For ProxyProvider)
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AuthProvider with ChangeNotifier {
  String _userId = "12345";
  String get userId => _userId;
}

// 📌 User Profile Provider (Dependent on AuthProvider)
class UserProfile {
  final String userId;
  final String name;
  UserProfile(this.userId, this.name);
}

class UserProfileProvider {
  final AuthProvider auth;
  UserProfileProvider(this.auth);

  UserProfile get profile => UserProfile(auth.userId, "John Doe");
}

// 📌 ProxyProvider Screen (Auth & User Profile)
class ProxyProviderScreen extends StatelessWidget {
  const ProxyProviderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final userProfile = context.watch<UserProfileProvider>().profile;

    return Scaffold(
      appBar: AppBar(title: Text("ProxyProvider Example")),
      body: Center(
        child: Text(
          "User: ${userProfile.name} (ID: ${userProfile.userId})",
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
