// 📌 Simulated Real-Time Data (StreamProvider)

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

Stream<int> numberStream() async* {
  int i = 0;
  while (true) {
    await Future.delayed(Duration(microseconds: 1));
    yield i++;
  }
}

// 📌 StreamProvider Screen (Live Data)
class StreamProviderScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final number = context.watch<int>();

    return Scaffold(
      appBar: AppBar(title: Text("StreamProvider Example")),
      body: Center(
        child: Text("Number: $number", style: TextStyle(fontSize: 50)),
      ),
    );
  }
}


/*
//! flutter framework StreamBuilder

class StreamProviderScreen extends StatefulWidget {
  const StreamProviderScreen({super.key});

  @override
  State<StreamProviderScreen> createState() => _StreamProviderScreenState();
}

class _StreamProviderScreenState extends State<StreamProviderScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<int>(
        stream: numberStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator(); // Display a loading indicator when waiting for data.
          } else if (snapshot.hasError) {
            return Text(
              'Error: ${snapshot.error}',
            ); // Display an error message if an error occurs.
          } else if (!snapshot.hasData) {
            return Text(
              'No data available',
            ); // Display a message when no data is available.
          } else {
            return Center(
              child: Text(
                'Latest Number: ${snapshot.data}',
                style: TextStyle(fontSize: 24),
              ),
            ); // Display the latest number when data is available.
          }
        },
      ),
    );
  }
}

*/