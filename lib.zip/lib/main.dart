import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_state_management/BottomNavigations/BottomNavScreen.dart';
import 'package:provider_state_management/providers/ChangeNotifierProvider.dart';
import 'package:provider_state_management/providers/FutureProviderExample.dart';
import 'package:provider_state_management/providers/ProxyProviderEaxmple.dart';
import 'package:provider_state_management/providers/StaticProviderData.dart';
import 'package:provider_state_management/providers/StreamProviderEaxmple.dart';
// https://docs.flutter.dev/get-started/fundamentals/layout
//https://docs.flutter.dev/data-and-backend/state-mgmt/intro

// 📌 Main App with MultiProvider
void main() {
  runApp(
    MultiProvider(
      providers: [
        Provider<AppConstants>(
          create: (_) => AppConstants(),
        ), // Providing StringProvider
        // Provider<String>(create: (_) => "Static Provider Data"),
        ChangeNotifierProvider(create: (_) => CounterProvider()),
        FutureProvider<Widget>(
          create: (_) => fetchTeamName(),
          // initialData:    "Fetching...",
          initialData: Center(
            child: SizedBox(
              width: 200,
              height: 200,
              child: CircularProgressIndicator(),
            ),
          ),
          // initialData: Text(data),
        ),
        StreamProvider<int>(create: (_) => numberStream(), initialData: 0),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ProxyProvider<AuthProvider, UserProfileProvider>(
          update: (_, auth, __) => UserProfileProvider(auth),
        ),
      ],
      child: MyApp(),
    ),
  );
}

// 📌 MyApp
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // home: HomeScreen(),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/CommonProviderScreen': (context) => CommonProviderScreen(),
      },
    );
  }
}

// 📌 Home Screen (Navigates to Other Screens)
class HomeScreen extends StatelessWidget {
  double spaceV = 12;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Provider Examples")),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: ElevatedButton(
              onPressed: () {
                // Navigate to the second screen using the named route
                Navigator.pushNamed(context, '/CommonProviderScreen');
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (_) => CommonProviderScreen()),
                // );
              },
              child: Text("Common Provider"),
            ),
          ),
          SizedBox(height: spaceV),
          Center(
            child: ElevatedButton(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => CounterScreen()),
                  ),
              child: Text("ChangeNotifierProvider (Counter)"),
            ),
          ),
          SizedBox(height: spaceV),
          Center(
            child: ElevatedButton(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => FutureProviderScreen()),
                  ),
              child: Text("FutureProvider (API Call)"),
            ),
          ),
          SizedBox(height: spaceV),
          Center(
            child: ElevatedButton(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => StreamProviderScreen()),
                  ),
              child: Text("StreamProvider (Live Data)"),
            ),
          ),
          SizedBox(height: spaceV),
          Center(
            child: ElevatedButton(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ProxyProviderScreen()),
                  ),
              child: Text("ProxyProvider (Auth & Profile)"),
            ),
          ),
          SizedBox(height: spaceV + spaceV),
          Center(
            child: ElevatedButton(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => BottomNavScreen()),
                  ),
              child: Text("Bottom Navigations"),
            ),
          ),
        ],
      ),
    );
  }
}
